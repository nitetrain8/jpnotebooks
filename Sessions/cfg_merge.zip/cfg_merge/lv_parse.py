import json


class LVType():
    def __init__(self, typ, name, val):
        self.typ = typ
        self.name = name
        self.val = val
        
    def iscontainer(self):
        return self.typ == "Cluster"
        
    def dump(self, ind=0):
        s = ind*" "
        if self.typ == "Cluster" or self.typ == "Array":
            print(s+self.name+" "+self.typ)
            for v in self.val:
                v.dump(ind+1)
        else:
            print(s+self.name + " " + self.typ+" "+repr(self.val))
            
    def lookup(self, key):
        if self.typ == "Cluster":
            for v in self.val:
                if v.name == key:
                    return v
            else:
                raise KeyError(key)
        elif self.typ == "Array":
            return self.val[key]
        else:
            raise TypeError("LVType(%r) does not support lookup"%self.typ)
            
    __getitem__ = lookup

    def get(self, key, default=None):
        try:
            return self.lookup(key)
        except KeyError:
            return default
            
    def __iter__(self):
        return iter(self.val)
    
    def _toxml(self, b):
        """ Write lines to buffer b"""
        if self.typ == "Cluster":
            b.append("<Cluster>")
            b.append("<Name>%s</Name>"%self.name)
            b.append("<NumElts>%d</NumElts>"%len(self.val))
            for v in self.val:
                v._toxml(b)
            b.append("</Cluster>")
        elif self.typ == "Choice":
            b.append("<%s>%s</%s>"%(self.typ, self.val, self.typ))
        elif isinstance(self.val,float):
            b.append("<%s>"%self.typ)
            b.append("<Name>%s</Name>"%self.name)
            b.append("<Val>%.5f</Val>"%self.val)
            b.append("</%s>"%self.typ)
        elif isinstance(self.val,int):
            b.append("<%s>"%self.typ)
            b.append("<Name>%s</Name>"%self.name)
            b.append("<Val>%d</Val>"%self.val)
            b.append("</%s>"%self.typ)
        else:
            raise TypeError("LVData(%r) does not support XML dump"%self.typ)

    def toxml(self):
        b = []
        self._toxml(b)
        return "\n".join(b)

    def _todict(self):
        if self.typ == "Cluster":
            ob = {}
            for v in self.val:
                ob[v.name] = v._todict()
            return ob
        elif self.typ == "Array":
            ob = []
            for v in self.val:
                ob.append(v._todict())
            return ob
        else:
            return self.val

    def tojson(self, **kw):
        return json.dumps(self._todict(), **kw)

    def tostr(self):
        if self.typ in ("DBL", "SGL"):
            return "%.5f"%self.val
        elif self.typ in {"U8", "U16", "U32", "I8", "I16", "I32"}:
            return "%d"%self.val
        else:
            raise TypeError(self.typ + " Unsupported for tostr()")


def _lv_parse_cluster(e):
    name = e[0].text
    val = []
    for el in e[2:]:
        v = lv_parse(el)
        val.append(v)
    return name, val

def _lv_parse_float(e):
    name = e[0].text
    val = float(e[1].text)
    return name, val

def _lv_parse_int(e):
    name = e[0].text
    val = int(e[1].text)
    return name, val

def _lv_parse_ew(e):
    # this only occurs in OLD (1.3 and before)
    # config files, for bioreactor model. 
    return e[0].text, list(e[1:-1])

_skip = object()

_lv_parse_types = {
    'Cluster': _lv_parse_cluster,
    "DBL"    : _lv_parse_float,
    "SGL": _lv_parse_float,
    'U8': _lv_parse_int,
    'U16': _lv_parse_int,
    'U32': _lv_parse_int,
    'I8': _lv_parse_int,
    'I16': _lv_parse_int,
    'I32': _lv_parse_int,
    'EW': _lv_parse_ew,
}

def lv_parse(e):
    typ = e.tag
    func = _lv_parse_types[typ]
    if func is not _skip:
        name, val = func(e)
        return LVType(typ, name, val)

def lv_parse_string(s):
    return lv_parse(lxml.etree.fromstring(s))

def lv_parse_file(f):
    return lv_parse(lxml.etree.parse(f))

def dump(e, ind=0):
    inds = " "*ind
    print(inds+"<%s>"%e.tag)
    for el in e:
        if len(el):
            dump(el, ind+1)
        else:
            print(inds+"<%s>%s</%s>"%(el.tag, el.text, el.tag))
    print(inds+"</%s>"%e.tag)