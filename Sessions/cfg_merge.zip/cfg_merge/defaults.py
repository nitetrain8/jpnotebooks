def_defaults = 'D:\\auto_hd_install\\default configs'
def_backups = "D:\\Customer_Backups"